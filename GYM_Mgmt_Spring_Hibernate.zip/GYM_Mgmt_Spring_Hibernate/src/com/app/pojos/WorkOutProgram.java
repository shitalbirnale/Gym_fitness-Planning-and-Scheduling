package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(schema = "system")
public class WorkOutProgram {
	// D.M
	private Integer w_id;
	private String workouttype; // example:- Weight Loss, Muscle Building
	private Date date_of_workout;
	private int duration;
	private double weight;
	// private double calories;
	private String diet_plan;

	// Default Constructor
	public WorkOutProgram() {
		System.out.println("in workout program table");
		// super();

	}

	private Member member;

	private Trainer trainer;

	// workout to member one to one mapping

	@ManyToOne
	@JoinColumn(name = "m_id")
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	// one to one mapping --> workoutprogram to trainer
	@OneToOne
	@JoinColumn(name = "t_id")
	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	// getter And Setter

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getW_id() {
		return w_id;
	}

	public void setW_id(Integer w_id) {
		this.w_id = w_id;
	}

	@Column(length = 30)
	public String getWorkouttype() {
		return workouttype;
	}

	public void setWorkouttype(String workouttype) {
		this.workouttype = workouttype;
	}

	public Date getDate_of_workout() {
		return date_of_workout;
	}

	public void setDate_of_workout(Date date_of_workout) {
		this.date_of_workout = date_of_workout;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getDiet_plan() {
		return diet_plan;
	}

	public void setDiet_plan(String diet_plan) {
		this.diet_plan = diet_plan;
	}

	public WorkOutProgram(String workouttype, Date date_of_workout, int duration, double weight, String diet_plan,
			Member member, Trainer trainer) {
		super();
		this.workouttype = workouttype;
		this.date_of_workout = date_of_workout;
		this.duration = duration;
		this.weight = weight;
		this.diet_plan = diet_plan;
		this.member = member;
		this.trainer = trainer;
	}

	@Override
	public String toString() {
		return "WorkOutProgram [w_id=" + w_id + ", workouttype=" + workouttype + ", date_of_workout=" + date_of_workout
				+ ", duration=" + duration + ", weight=" + weight + ", diet_plan=" + diet_plan + ", member=" + member
				+ ", trainer=" + trainer + "]";
	}

	public WorkOutProgram(String workouttype, Date date_of_workout, int duration, double weight, String diet_plan,
			Trainer trainer) {
		super();
		this.workouttype = workouttype;
		this.date_of_workout = date_of_workout;
		this.duration = duration;
		this.weight = weight;
		this.diet_plan = diet_plan;
		this.trainer = trainer;
	}

}
