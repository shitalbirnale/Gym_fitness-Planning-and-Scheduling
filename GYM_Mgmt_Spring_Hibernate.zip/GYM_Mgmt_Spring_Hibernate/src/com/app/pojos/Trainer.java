package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(schema = "system")
public class Trainer {
	// data members
	private Integer t_ID;
	private String t_name;
	private String email;
	private String t_password;
	private String mobno;
	private String address;
	private double salary;

	private List<Member> member = new ArrayList<>();

	// Default Constructor
	public Trainer() {
		// super();
		System.out.println("In trainer Pojo ");

	}

	private List<WorkOutProgram> workoutprogram = new ArrayList<>();

	// one to many mapping trainer --> workoutprogram
	@OneToMany(mappedBy = "trainer", cascade = CascadeType.ALL)
	public List<WorkOutProgram> getWorkoutprogram() {
		return workoutprogram;
	}

	public void setWorkoutprogram(List<WorkOutProgram> workoutprogram) {
		this.workoutprogram = workoutprogram;
	}

	// one to many mapping --->trainer-->member
	@OneToMany(mappedBy = "trainer", cascade = CascadeType.ALL)
	public List<Member> getMember() {
		return member;
	}

	public void setMember(List<Member> member) {
		this.member = member;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getT_ID() {
		return t_ID;
	}

	public void setT_ID(Integer t_ID) {
		this.t_ID = t_ID;
	}

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}

	public String getT_password() {
		return t_password;
	}

	public void setT_password(String t_password) {
		this.t_password = t_password;
	}

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// Parameterized Default Constructor
	public Trainer(String t_name, String email, String t_password, String mobno, String address, double salary,
			List<Member> member, List<WorkOutProgram> workoutprogram) {
		super();
		this.t_name = t_name;
		this.email = email;
		this.t_password = t_password;
		this.mobno = mobno;
		this.address = address;
		this.salary = salary;
		this.member = member;
		this.workoutprogram = workoutprogram;
	}

	public Trainer(String t_name, String email, String t_password, String mobno, String address, double salary) {
		super();
		this.t_name = t_name;
		this.email = email;
		this.t_password = t_password;
		this.mobno = mobno;
		this.address = address;
		this.salary = salary;
	}

}
