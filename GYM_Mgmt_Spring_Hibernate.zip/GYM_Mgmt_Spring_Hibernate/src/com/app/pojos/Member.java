package com.app.pojos;

import javax.persistence.*;

@Entity
@Table(schema = "system")
public class Member {

	private Integer m_ID;
	private String email;
	private String password;
	private String mobile_No;
	private String name;

	// One to One
	private MemberProfile memberprofile;

	// one to one
	private WorkOutProgram workoutprogram;

	// one to one
	private Physical_Info physical_info;

	// many to one
	private Trainer trainer;

	// one to one mapped--> member to memberprofile
	@OneToOne(mappedBy = "member", cascade = CascadeType.ALL)
	public MemberProfile getMemberprofile() {
		return memberprofile;
	}

	public void setMemberprofile(MemberProfile memberprofile) {
		this.memberprofile = memberprofile;
	}

	// one to one mapped --> member to workoutprogram

	@OneToOne(mappedBy = "member", cascade = CascadeType.ALL)
	public WorkOutProgram getWorkoutprogram() {
		return workoutprogram;
	}

	public void setWorkoutprogram(WorkOutProgram workoutprogram) {
		this.workoutprogram = workoutprogram;
	}

	// one to one member to physical info

	@OneToOne(mappedBy = "member", cascade = CascadeType.ALL)
	public Physical_Info getPhysical_info() {
		return physical_info;
	}

	public void setPhysical_info(Physical_Info physical_info) {
		this.physical_info = physical_info;
	}

	@ManyToOne
	@JoinColumn(name = "t_id")
	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	// Default Constructor
	public Member() {
		System.out.println("In Member ");
	}

	// Parameterized Default Constructor

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getM_ID() {
		return m_ID;
	}

	public void setM_ID(Integer m_ID) {
		this.m_ID = m_ID;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile_No() {
		return mobile_No;
	}

	public void setMobile_No(String mobile_No) {
		this.mobile_No = mobile_No;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Member(String email, String password, String mobile_No, String name, MemberProfile memberprofile,
			WorkOutProgram workoutprogram, Physical_Info physical_info, Trainer trainer) {
		super();
		this.email = email;
		this.password = password;
		this.mobile_No = mobile_No;
		this.name = name;
		this.memberprofile = memberprofile;
		this.workoutprogram = workoutprogram;
		this.physical_info = physical_info;
		this.trainer = trainer;
	}

	public Member(String email, String password, String mobile_No, String name, Trainer trainer) {
		super();
		this.email = email;
		this.password = password;
		this.mobile_No = mobile_No;
		this.name = name;
		this.trainer = trainer;
	}

}
