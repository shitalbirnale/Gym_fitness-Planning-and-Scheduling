package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(schema = "system")
public class Physical_Info {
	// D.M
	private Integer p_id;
	private float weight;
	// private double height;
	private int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	private Date dates;
	private String bloodgroup;
	private float fat;

	private Member member;

	public Physical_Info() {
		// super();
		System.out.println("in physical info");
		// TODO Auto-generated constructor stub
	}

	@OneToOne
	@JoinColumn(name = "m_id")
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getP_id() {
		return p_id;
	}

	public void setP_id(Integer p_id) {
		this.p_id = p_id;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public float getFat() {
		return fat;
	}

	public void setFat(float fat) {
		this.fat = fat;
	}

	public Date getDates() {
		return dates;
	}

	public void setDates(Date dates) {
		this.dates = dates;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public Physical_Info(float weight, int age, Date dates, String bloodgroup, float fat, Member member) {
		super();
		this.weight = weight;
		this.age = age;
		this.dates = dates;
		this.bloodgroup = bloodgroup;
		this.fat = fat;
		this.member = member;
	}

	public Physical_Info(float weight, int age, float fat) {
		super();
		this.weight = weight;
		this.age = age;
		this.fat = fat;
	}

	public Physical_Info(float weight, int age, Date dates, String bloodgroup, float fat) {
		super();
		this.weight = weight;
		this.age = age;
		this.dates = dates;
		this.bloodgroup = bloodgroup;
		this.fat = fat;
	}

	@Override
	public String toString() {
		return "Physical_Info [p_id=" + p_id + ", weight=" + weight + ", age=" + age + ", dates=" + dates
				+ ", bloodgroup=" + bloodgroup + ", fat=" + fat + ", member=" + member + "]";
	}

}
