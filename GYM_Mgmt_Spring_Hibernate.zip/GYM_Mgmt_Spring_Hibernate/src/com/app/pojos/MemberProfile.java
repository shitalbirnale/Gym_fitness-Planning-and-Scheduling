package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(schema = "system")
public class MemberProfile {

	private int age;
	private String address;
	private String gender;
	private float height;
	private float weight;

	@DateTimeFormat(pattern = "dd-MM-yyyy")

	private Date date_of_join;
	private int membership_id;
	private Integer memberprofile_id;

	private Member member;

	@OneToOne
	@JoinColumn(name = "m_id")
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public MemberProfile() {

		System.out.println("In memberProfile pojo");
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	@Temporal(TemporalType.DATE)
	public Date getDate_of_join() {
		return date_of_join;
	}

	public void setDate_of_join(Date date_of_join) {
		this.date_of_join = date_of_join;
	}

	public int getMembership_id() {
		return membership_id;
	}

	public void setMembership_id(int membership_id) {
		this.membership_id = membership_id;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getMemberprofile_id() {
		return memberprofile_id;
	}

	public void setMemberprofile_id(Integer memberprofile_id) {
		this.memberprofile_id = memberprofile_id;
	}

	public MemberProfile(String address, String gender, float height, float weight, Date date_of_join,
			int membership_id, Member member) {
		super();
		this.address = address;
		this.gender = gender;
		this.height = height;
		this.weight = weight;
		this.date_of_join = date_of_join;
		this.membership_id = membership_id;
		this.member = member;
	}

	@Override
	public String toString() {
		return "MemberProfile [age=" + age + ", address=" + address + ", gender=" + gender + ", height=" + height
				+ ", weight=" + weight + ", date_of_join=" + date_of_join + ", membership_id=" + membership_id
				+ ", memberprofile_id=" + memberprofile_id + ", member=" + member + "]";
	}

	public MemberProfile(int age, String address, String gender, float height, float weight, Date date_of_join,
			Member member) {
		super();
		this.age = age;
		this.address = address;
		this.gender = gender;
		this.height = height;
		this.weight = weight;
		this.date_of_join = date_of_join;
		this.member = member;
	}

}
