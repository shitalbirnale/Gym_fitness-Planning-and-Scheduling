package com.app.pojos;

import javax.persistence.*;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "system")
public class Admin {

	private String email;
	private String password;
	private Integer aid;

	// Default Constructor
	public Admin() {
		System.out.println(" in admin pojo");

	}

	// Parameterized Default Constructor
	public Admin(String email, String password) {

		this.email = email;
		this.password = password;

	}

	// getter and setter

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getAid() {
		return aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

}
