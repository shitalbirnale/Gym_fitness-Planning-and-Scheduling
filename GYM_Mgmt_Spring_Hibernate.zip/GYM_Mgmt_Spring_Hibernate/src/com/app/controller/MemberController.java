
package com.app.controller;


import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.Interface_Admin;
import com.app.dao.Interface_Member;
import com.app.dao.Interface_Trainer;
import com.app.pojos.Admin;
import com.app.pojos.Member;
import com.app.pojos.MemberProfile;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	
	
	@Autowired
	private Interface_Member dao;
	
	@Autowired
	private Interface_Trainer tdao;


	public MemberController()
	{
		
		System.out.println("in MemberController constructor");
	}
	
	
	@GetMapping("/login")
	public String ShowLoginForm()
	{
		System.out.println("in show login form of member get ");
		
	return "/member/login";	
	}
	
	
	@PostMapping("/login")
	public String LoginForm(@RequestParam String nm,@RequestParam String password, Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		System.out.println("Member login post method");
		Member m;
	
		try {
			System.out.println(nm+"  "+password);
			
			m = dao.authanticate(nm, password);
			
			System.out.println(m);
			
			if(m!=null)
			{ 
				hs.setAttribute("member",m );
				MemberProfile mp;
				
				//m=dao.allDetails(nm, password);
				
				System.out.println("get id of Member");
				
				mp=m.getMemberprofile();
				
				System.out.println("check memberprofile table data exist or not with respect to member id");
				
					if(mp!=null)
					{
						return "/member/profile";
					}
					else 
					{
						return "redirect:/member/memberPhysicalinfo";
					}
					
			}	
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "/member/login";
		
	}
	
	
	// logout
		@GetMapping("/logout")
		public String Logout(HttpSession hs)
		{
			hs.invalidate();
			
		return "redirect:/member/login";	
		}
	
	
	
	@GetMapping("/profile")
	public String Profile(Model map)
	{
		
		
	return "/member/profile";	
	}
	
	

	
		// member register
	
	@GetMapping("/register")
	public String registerForm(Model map)
	{
		System.out.println("in Member register get mthod");
		
		List<Trainer> ls=dao.getAllTrainer();
		
		map.addAttribute("trainer_dtls",ls);
		
		System.out.println("result of register"+ls.size());
		
	return "/member/register";	
	}
	
	
	@PostMapping("/register")
	public String registerForm(@RequestParam String nm,@RequestParam String email,@RequestParam String password,
			@RequestParam String mobno,@RequestParam int abc,Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		
		System.out.println("Member register post method");
		
		Trainer t=tdao.getTrainerById(abc);
		
		Member m=new Member(email,password,mobno,nm,t);
		
		System.out.println(m);
		
		String member=dao.registerMember(m);
		
		
		System.out.println("Member added data");
		return "redirect:/member/login";
		
	}
		
	
	
	// member physical info filled for first time login members
	
	@GetMapping("/memberPhysicalinfo")
	public String MemberprofileRegister(Model map)
	{
	
		System.out.println("in get method of memberprofile");
	return "/member/memberPhysicalinfo";	
	}
	
	
	
	@PostMapping("/memberPhysicalinfo")
	public String PhysicalInfoForm(@RequestParam int member_age,@RequestParam float member_height,@RequestParam float member_weight,
			@RequestParam String member_bloodgroup,@RequestParam String member_address,@RequestParam Date member_dateofjoin ,@RequestParam String gender,Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		System.out.println("in member profile info method");
		hs.getAttribute("member");
		
		Member m=(Member) hs.getAttribute("member");
		
		MemberProfile memberprofiles=new MemberProfile(member_age,member_address,gender,member_height,member_weight,member_dateofjoin,m);
		
		System.out.println("after dao of member profile");
		
		String MemberProfile=dao.registerMemberprofile(memberprofiles);
		
		return "redirect:/member/profile";
	}
	
	
	
	
	// Show Member Physical Information
	
	@GetMapping("/ShowMemberPhysicalInfo")
	public String MemberPhysicalInfoList(Model map,HttpSession hs)
	{

		System.out.println("in member physical info get mthod");
		try {
		int m=(int) hs.getAttribute("member");
		
		List<Physical_Info> ls=dao.getAllPhysicalInfo(m);
		
		
		System.out.println("after dao call");
		
		map.addAttribute("physicalinfo",ls);
		
		System.out.println("result of register"+ls.size());	
		
	return "/member/memberPhysicalinfoList";	
		}
		
		catch(Exception e) {e.printStackTrace();}
	
		return "/member/error_page";
	}
	
	
	
	
	
	// Show Member Work Out Information
	
	@GetMapping("/ShowMemberWorkOutProgram")
	public String MemberWorkoutList(Model map)
	{

		System.out.println("in member workout get mthod");
		
		List<WorkOutProgram> ls=dao.getAllWorkoutProgram();
		
		
		System.out.println("after dao call");
		
		map.addAttribute("workout",ls);
		
		System.out.println("result of register"+ls.size());
		
	return "/member/memberWorkoutProgram";	
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	@PostMapping
	public ResponseEntity<?> createNewStock(@RequestParam String email,@RequestParam String pass) throws Exception
	{
		System.out.println("in create new stock ");
		try 
		{
			return new ResponseEntity<Member>(dao.authanticate(email, pass), HttpStatus.CREATED);
		} 
		catch (RuntimeException e) 
		{return new ResponseEntity<String>("error",HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	*/
	
	
	

}
