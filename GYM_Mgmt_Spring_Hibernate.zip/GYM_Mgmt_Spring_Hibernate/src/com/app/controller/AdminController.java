package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.Interface_Admin;
import com.app.dao.Interface_Member;
import com.app.dao.Interface_Trainer;
import com.app.pojos.Admin;
import com.app.pojos.Member;
import com.app.pojos.Trainer;


//@RestController
@Controller
@RequestMapping("/admin")
public class AdminController 
{
	@Autowired
	private Interface_Admin dao;
	@Autowired
	private Interface_Trainer tdao;

	@Autowired
	private Interface_Member mdao;

	
	
	public AdminController()
	{
		
		System.out.println("in AdminController constructor");
	}
	
	// admin login
	
	@GetMapping("/login")
	public String getUserDetails()
	{
		System.out.println("in show login form of get ");
		
	return "/admin/login";	
	}
	
	
	// logout
	@GetMapping("/logout")
	public String Logout(HttpSession hs)
	{
		hs.invalidate();
		
	return "redirect:/admin/login";	
	}
	
	
	
	@PostMapping("/login")
	public String LoginForm(@RequestParam String nm,@RequestParam String password, Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		Admin a;
		try {
			a = dao.authanticate(nm, password);

			if(a!=null)
				hs.setAttribute("admin", a);
				return "/admin/details";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/admin/login";
		
	}
	
	//show trainer list
	
	@GetMapping("/trainerlist")
	public String trainerList(Model map,HttpSession hs)
	{
		Admin a=(Admin) hs.getAttribute("admin");
		if(a!=null) 
		{
		System.out.println("in trainer register get mthod");
		
		List<Trainer> ls=dao.getAllTrainer();
		
		
		System.out.println("after dao call");
		
		map.addAttribute("trainer_dtls",ls);
		
		System.out.println("result of register"+ls.size());
		
	return "/admin/tlist";	
		}
		return "/admin/login";
	}
	
	
			// show member list
	@GetMapping("/memberlist")
	public String memberList(Model map,HttpSession hs)
	{
		Admin a=(Admin) hs.getAttribute("admin");
		
		if(a!=null) 
		{
	try {
		System.out.println("in member register get mthod");
		
		List<Member> ls=dao.getAllMember();
		
		
		System.out.println("after dao call");
		
		map.addAttribute("member_dtls",ls);
		
		System.out.println("result of register"+ls.size());
		
		return "/admin/membersList";	
		}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return "/admin/memberregister";
	
	}
		return "/admin/login";
	}
	
	
		//  search member By Name
	@PostMapping("/memberlist")
	public String Search_Member(@RequestParam String nm,Model map,HttpSession hs)
	{
		try 
		{
		map.addAttribute("Member_searched", dao.Search_Member(nm));
		
		return"/admin/membersList";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return"redirect:/admin/memberlist";
	}
	
	
	//  search Trainer By Name
	@PostMapping("/trainerlist")
	public String Search_Trainer(@RequestParam String nm,Model map,HttpSession hs)
	{
		
		try 
		{
				System.out.println("search tariner by name in controller:");
		
				map.addAttribute("Trainer_searched", dao.Search_Trainer(nm));
		
			return"/admin/tlist";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return"redirect:/admin/trainerlist";
	}
	
	
	
	
	
	
	
	
	
	
	// delete trainer			
	
	@GetMapping("/delete")
	public String deleteMember(@RequestParam int m_ID, RedirectAttributes flashMap) {
		System.out.println("in del member " + m_ID);
		
		flashMap.addFlashAttribute("mesg", dao.deleteMember(m_ID));
		
		
		return "redirect:/admin/memberlist";
	}
	
	
	@GetMapping("/trainerdelete")
	public String deleteTrainer(@RequestParam int t_ID, RedirectAttributes flashMap) {
		
		System.out.println("in del trainer " + t_ID);
		
		flashMap.addFlashAttribute("mesg", dao.deleteTrainer(t_ID));
		
		
		return "redirect:/admin/trainerlist";
	}
	
	
		// trainer register
	@GetMapping("/register")
	public String registerForm()
	{
		System.out.println("in trainer register get mthod");
		
	return "/admin/register";	
	}
	
	
	@PostMapping("/register")
	public String registerForm(@RequestParam String nm,@RequestParam String email,@RequestParam String password,@RequestParam String addr,
			@RequestParam String mobno,@RequestParam int sal,Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		
		System.out.println("trainer register post method");
		
		Trainer t=new Trainer(nm,email,password,mobno,addr,sal);
		
		String s=tdao.registerTrainer(t);
		
		System.out.println("trainer added data");
		
		return "redirect:/admin/trainerlist"
				+ "";
		
	}
	
				// member register
		
	@GetMapping("/memberregister")
		public String registerForm(Model map)
		{
			System.out.println("in Member register get mthod");
			
			List<Trainer> ls=dao.getAllTrainer();
			
			map.addAttribute("trainer_dtls",ls);
			
			System.out.println("result of register"+ls.size());
			
		return "/admin/memberregister";	
		}
		
		
		@PostMapping("/memberregister")
		public String registerForm(@RequestParam String nm,@RequestParam String email,@RequestParam String password,
				@RequestParam String mobno,@RequestParam int abc,Model map,
				RedirectAttributes flashMap, HttpSession hs)
		{
			
			System.out.println("Member register post method");
			
			Trainer t=tdao.getTrainerById(abc);
			
			Member m=new Member(email,password,mobno,nm,t);
			
			System.out.println(m);
			
			String member=mdao.registerMember(m);
			
			
			System.out.println("Member added data");
			return "redirect:/admin/memberlist";
			
		}
			

		
		
		// edit member form
		@GetMapping("/memberEditForm")
		
		public String EditMemberForm()
		{
			System.out.println("in trainer register get mthod");
			
		return "/admin/memberEditForm";	
		}
		
		@PostMapping("/memberEditForm")
		public String UpdateMemberForm(@RequestParam String nm,@RequestParam String email,@RequestParam String password,
				@RequestParam String mobno,@RequestParam int abc,Model map,
				RedirectAttributes flashMap, HttpSession hs)
		{
			
			System.out.println("Member update post method");
			
			Trainer t=tdao.getTrainerById(abc);
			
			Member m=new Member(email,password,mobno,nm,t);
			
			System.out.println(m);
			
			String member=mdao.registerMember(m);
			
			
			System.out.println("Member  data update");
			return "redirect:/admin/memberlist";
			
		}
	
	
	/*
	@PostMapping("")
	public String tList(Model map)
	{

		System.out.println("in trainer register get mthod");
		
		List<String> ls=dao.getAllTrainer();
		
		map.addAttribute("trainer_dtls",ls);
		
		System.out.println("result of register"+ls.size());
		
	return "/admin/tlist";	
	}
	*/
	
	
/*	
	@PostMapping
	public ResponseEntity<?> createNewStock(@RequestParam String email,@RequestParam String pass) throws Exception
	{
		System.out.println("in create new stock ");
		try 
		{
			return new ResponseEntity<Admin>(dao.authanticate(email, pass), HttpStatus.CREATED);
		} 
		catch (RuntimeException e) 
		{return new ResponseEntity<String>("error",HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	*/

}
