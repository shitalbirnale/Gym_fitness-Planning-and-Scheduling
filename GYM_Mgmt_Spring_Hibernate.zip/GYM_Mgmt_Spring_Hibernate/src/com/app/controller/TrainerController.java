package com.app.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.dao.Interface_Member;
import com.app.dao.Interface_Trainer;
import com.app.pojos.Admin;
import com.app.pojos.Member;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

@Controller
@RequestMapping("/trainer")
public class TrainerController {

	
	
	
	@Autowired
	private Interface_Trainer dao;
	
	
	
	
	public TrainerController()
	{
		
		System.out.println("in TrainerController constructor");
	}
	
	// Login 
	
	@GetMapping("/login")
	public String ShowLoginForm()
	{
		System.out.println("in show login form of get of TrainerController");
		
	return "/trainer/login";	
	}
	
	
	@PostMapping("/login")
	public String LoginForm(@RequestParam String nm,@RequestParam String password, Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		Trainer t;
		try {
			t= dao.authanticate(nm, password);
			System.out.println("result of authenticate"+t);

			if(t!=null)
				hs.setAttribute("tr", t);
				return "/trainer/profile";
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "/trainer/login";
		
	}
	// logout
			@GetMapping("/logout")
			public String Logout(HttpSession hs)
			{
				hs.invalidate();
				
			return "redirect:/trainer/login";	
			}
	
	//trainer register
	
	@GetMapping("/register")
	public String registerForm()
	{
		System.out.println("in trainer register get mthod");
		
	return "/trainer/register";	
	}
	
	
	
	@PostMapping("/register")
	public String registerForm(@RequestParam String nm,@RequestParam String email,@RequestParam String password,@RequestParam String addr,
			@RequestParam String mobno,@RequestParam int sal,Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		
		System.out.println("trainer register post method");
		
		Trainer t=new Trainer(nm,email,password,mobno,addr,sal);
		
		String s=dao.registerTrainer(t);
		
		System.out.println("trainer added data");
		
		return "redirect:/trainer/login";
		
	}
		
	
	 
	
	
			// show member list
	
	@GetMapping("/memberlist")
	public String memberList(Model map,HttpSession hs)
	{

		System.out.println("in member register get mthod");
	
		Trainer t=(Trainer)hs.getAttribute("tr"); 

	
		List<Member> ls=dao.getAllMemberbyTid(t.getT_ID());
	
		hs.setAttribute("memberlist", ls);
		System.out.println("after dao call");
	
		map.addAttribute("member_dtls",ls);
	
		System.out.println("result of register"+ls.size());
	
		return "/trainer/membersList";	
	}

	
	@PostMapping("/memberlist")
	public String Search_Member(@RequestParam String nm,Model map,HttpSession hs)
	{
		try 
		{
				map.addAttribute("Member_searched", dao.Search_Member(nm));
		
				return"/trainer/membersList";
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		}
		
		return "redirect:/trainer/memberlist";
	
	}
	
	
	

	
	

			// Delete the Member

		@GetMapping("/delete")
		public String deleteMember(@RequestParam int m_ID, RedirectAttributes flashMap)
		{
	
			System.out.println("in del member " + m_ID);
	
			flashMap.addFlashAttribute("mesg", dao.deleteMember(m_ID));
	
	
			return "redirect:/trainer/memberlist";
		}




			//update physical information of Member

		@GetMapping("/physicalinfo")
		public String showPhysicalInfo(Model map, RedirectAttributes flashMap,@RequestParam int m_ID,HttpSession hs)
		{
	
			System.out.println("in show physical info member ");
	
			hs.setAttribute("memberid", m_ID);
	
			Physical_Info f;
	
			try 
			{
	
				System.out.println("in physical info member " + m_ID);
	
	
	
				f=dao.getPhysicalinfo(m_ID);
		
				System.out.println(f);
		
				if(f!=null)	
	
					map.addAttribute("physicalinfo",f);

				return "/trainer/memberphysicalinfo";
	
			}
			catch (Exception e) 
			{
		
					e.printStackTrace();
			}
				return "redirect:/trainer/Registerphysicalinfo";
	
	
	}
	
		// update physical information via form
		@GetMapping("/update")
		public String physicalform() 
		{
	

			return "/trainer/physicalinfoform";
		}



		@PostMapping("/update")
		public String updateForm(@RequestParam int bmi,@RequestParam float weight,@RequestParam float fat ,Model map,
		RedirectAttributes flashMap, HttpSession hs)
		{
	
			System.out.println("member update form post method");
	
			int m=(int) hs.getAttribute("memberid");
		
			System.out.println(m);

	
			String s=dao.PhysicalInfoUpdate(bmi, weight, fat, m);
	
			System.out.println("after dao of update");
	
			return "redirect:/trainer/memberlist";
	
		}



		
		// show workout type of member

		@GetMapping("/workouttype")
		public String showWorkouttype(Model map, RedirectAttributes flashMap,@RequestParam int m_ID,HttpSession hs)
		{
	
			System.out.println("in workout get method member ");
	
			hs.setAttribute("memberid", m_ID);
	
			System.out.println( hs.getAttribute("memberid"));

			System.out.println("in physical info member " + m_ID);
	
			WorkOutProgram wp;
	
			try
			{
	
				wp=dao.getWorkOutProgram(m_ID);

			if(wp!=null)
				
				map.addAttribute("workout_dtls",wp);
		
				return "/trainer/MemberWorkOut";
	
			}
			catch (Exception e) 
			{
		
				e.printStackTrace();
			}
				return "redirect:/trainer/Register_Workout_Program";
	
	
}



	//	Register Physical Information 

@GetMapping("/Registerphysicalinfo")
public String RegisterPhysicalInformatiob() {
	
System.out.println("register physical info");
	return "/trainer/Registerphysicalinfo";
}

@PostMapping("/Registerphysicalinfo")
public String Register_Physical_Form(@RequestParam int bmi,@RequestParam float weight,@RequestParam float fat ,@RequestParam Date date,@RequestParam String bloodgrp,Model map,
		RedirectAttributes flashMap, HttpSession hs)
{
	
	
		System.out.println("member insert physical info form post method");
	
		int n= (int) hs.getAttribute("memberid");
		
			
		
		System.out.println(n);

		Physical_Info p=new Physical_Info(weight,bmi,date,bloodgrp,fat);
	
		String s=dao.InsertPhysicalInfo(p,n);
	
		System.out.println("after dao of update");
	
		return "redirect:/trainer/memberlist";
	
}






		// Register Workout-program (if -Not exist in Database)

	@GetMapping("/Register_Workout_Program")
	public String Register_Workout_Program() 
	{
	
		System.out.println("register Workout-Program");
	
		return "/trainer/Register_Workout_Program";
	}


	@PostMapping("/Register_Workout_Program")
	public String Register_Workout_Program_Form(@RequestParam int duration,@RequestParam float weight,@RequestParam String dietplan ,@RequestParam String worktype,@RequestParam String protein,@RequestParam Date date,Model map,
			RedirectAttributes flashMap, HttpSession hs)
	{
		
		
			System.out.println("insert workout-program form post method");
		
			int n= (int) hs.getAttribute("memberid");
			
			System.out.println(n);
			
			Trainer trainers= (Trainer) hs.getAttribute("tr");
			System.out.println("trainer object"+trainers);
			System.out.println("Member id in Register workout"+n);

			WorkOutProgram wp=new WorkOutProgram(worktype,date,duration,weight,dietplan,trainers);
			
			String register_workout=dao.Insert_Workout_Program(wp, n);
			
			System.out.println("after dao of register workout program");
		
			return "redirect:/trainer/memberlist";
		
	}











		// get to the change  workout form

@GetMapping("/changeworkout")
public String Workoutform() {
	

	return "/trainer/MemberWorkOutForm";
}



@PostMapping("/changeworkout")
public String updateForm(@RequestParam String workouttype,@RequestParam int duration,@RequestParam String dietplan ,Model map,
		RedirectAttributes flashMap, HttpSession hs)
{
	
	System.out.println("member change workout program post mapping");
	
	
	int mid=(int) hs.getAttribute("memberid");
	
	Trainer t=(Trainer)hs.getAttribute("tr"); 
	
	int tid= t.getT_ID();
	
	System.out.println(tid);
	
	
	String s=dao.WorkOutProgramUpdate(workouttype, duration, dietplan, mid, tid);
	
	
	
	
	return "redirect:/trainer/memberlist";
	
}










/*	
	@PostMapping
	public ResponseEntity<?> createNewStock(@RequestParam String email,@RequestParam String pass) throws Exception
	{
		System.out.println("in create new stock ");
		try 
		{
			return new ResponseEntity<Member>(dao.authanticate(email, pass), HttpStatus.CREATED);
		} 
		catch (RuntimeException e) 
		{return new ResponseEntity<String>("error",HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	*/
	
	
	
}
