package com.app.dao;

import java.util.List;

import com.app.pojos.Member;
import com.app.pojos.MemberProfile;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

public interface Interface_Member {
	
	
	public Member authanticate(String email,String pass) throws Exception;
	
	public List<Trainer> getAllTrainer();

	public String registerMember(Member m);
	

	public String registerMemberprofile(MemberProfile memberprofiles);

	public List<Physical_Info> getAllPhysicalInfo(int m);

	public List< WorkOutProgram > getAllWorkoutProgram();

	
	//public Member allDetails(String email,String pass);
	 
	//public MemberProfile GetMemberprofile(int mid);

	
	
}
