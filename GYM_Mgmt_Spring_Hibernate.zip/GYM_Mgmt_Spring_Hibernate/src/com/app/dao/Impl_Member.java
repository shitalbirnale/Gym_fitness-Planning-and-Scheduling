package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Member;
import com.app.pojos.MemberProfile;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

@Repository
@Transactional
public class Impl_Member implements Interface_Member {

	@Autowired
	private SessionFactory sf;

	@Override
	public Member authanticate(String email, String pass) throws Exception {

		String jpql = "select m from Member m where m.email=:em and m.password=:pwd";

		System.out.println("login jpql query");
		Member m = sf.getCurrentSession().createQuery(jpql, Member.class).setParameter("em", email)
				.setParameter("pwd", pass).getSingleResult();
		System.out.println(jpql);
		System.out.println(m);
		return m;
	}

	@Override
	public List<Trainer> getAllTrainer() {

		System.out.println("in trainer all trainer");

		String jpql = "select t from Trainer t";

		System.out.println("in trainer all trainer jpql");
		List<Trainer> list = sf.getCurrentSession().createQuery(jpql, Trainer.class).getResultList();
		return list;

	}

	// it can register new member
	@Override
	public String registerMember(Member m) {

		System.out.println("member impl");

		sf.getCurrentSession().persist(m);

		System.out.println("member saved");

		return "member registered successfully" + m.getM_ID();

	}

	// it can register member phsical information
	@Override
	public String registerMemberprofile(MemberProfile memberprofiles) {

		System.out.println("register member profile");

		sf.getCurrentSession().persist(memberprofiles);

		return "member profile details resitered successfully" + memberprofiles.getMemberprofile_id();
	}

	@Override
	public List<Physical_Info> getAllPhysicalInfo(int m) {
		System.out.println("in member get list of physical info dao");

		String jpql = "select pi from Physical_Info pi where pi.member.m_ID:=m";

		System.out.println("list of physical info in dao impl of member");

		List<Physical_Info> list = sf.getCurrentSession().createQuery(jpql, Physical_Info.class).setParameter("m", m).getResultList();

		return list;
	}

	@Override
	public List<WorkOutProgram> getAllWorkoutProgram() {
		System.out.println("in member workour program list");

		String jpql = "select w from WorkOutProgram w";

		System.out.println("list of physical info in dao impl of member");

		List<WorkOutProgram> list = sf.getCurrentSession().createQuery(jpql, WorkOutProgram.class).getResultList();

		return list;
	}

	/*
	 * @Override public Member allDetails(String email,String pass) {
	 * 
	 * String jpql="select m from Member m where m.email=:em and m.password=:pwd";
	 * 
	 * System.out.println("fetch Member id using email and password in dao impl");
	 * 
	 * return
	 * sf.getCurrentSession().createQuery(jpql,Member.class).setParameter("em",email
	 * ).setParameter("pwd",pass).getSingleResult();
	 * 
	 * }
	 * 
	 * 
	 * 
	 * @Override public MemberProfile GetMemberprofile(int mid) {
	 * System.out.println("getmemberprofile ");
	 * 
	 * String jpql="select mp from MemberProfile mp where mp.m_id=:id";
	 * 
	 * return
	 * sf.getCurrentSession().createQuery(jpql,MemberProfile.class).setParameter(
	 * "id",mid).getSingleResult(); }
	 */

}
