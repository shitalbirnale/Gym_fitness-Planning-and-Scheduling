package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Admin;
import com.app.pojos.Member;
import com.app.pojos.Trainer;

@Repository
@Transactional
public class Impl_Admin implements Interface_Admin {

	@Autowired
	private SessionFactory sf;

	@Override
	public Admin authanticate(String email, String Pass) throws Exception {

		String jpql = "select a from Admin a where a.email=:em and a.password=:pwd";

		return sf.getCurrentSession().createQuery(jpql, Admin.class).setParameter("em", email).setParameter("pwd", Pass)
				.getSingleResult();
	}

	@Override
	public List<Trainer> getAllTrainer() {

		System.out.println("in trainer all trainer");

		String jpql = "select t from Trainer t";

		System.out.println("in trainer all trainer jpql");

		return sf.getCurrentSession().createQuery(jpql, Trainer.class).getResultList();

	}

	@Override
	public List<Member> getAllMember() {

		System.out.println("in  all member");

		String jpql = "select m from Member m";

		System.out.println("in member dao jpql");

		return sf.getCurrentSession().createQuery(jpql, Member.class).getResultList();

	}

	@Override
	public String deleteMember(int m_Id) {
		Session hs = sf.getCurrentSession();
		Member m = hs.get(Member.class, m_Id);
		if (m != null) {
			hs.delete(m);
			return "Member un-subscribed with ID " + m.getM_ID();
		}
		return "member deletion failed : Invalid Member ID";
	}

	@Override
	public String deleteTrainer(int t_ID) {
		Session hs = sf.getCurrentSession();
		Trainer t = hs.get(Trainer.class, t_ID);
		if (t != null) {
			hs.delete(t);
			return "Trainer un-subscribed with ID " + t.getT_ID();
		}
		return "Trainer deletion failed : Invalid trainer ID";
	}

	// Search Member By Name
	@Override
	public Member Search_Member(String names) {

		String jpql = "select m from Member m where m.name=:names";

		System.out.println("in search Member in dao");

		Member m = sf.getCurrentSession().createQuery(jpql, Member.class).setParameter("names", names)
				.getSingleResult();

		return m;
	}

	// search Trainer By name
	@Override
	public Trainer Search_Trainer(String name) {

		String jpql = "select t from Trainer t where t.t_name=:names";

		System.out.println("in search Trainer in dao");

		Trainer t = sf.getCurrentSession().createQuery(jpql, Trainer.class).setParameter("names", name)
				.getSingleResult();

		return t;
	}

	/*
	 * @Override public String registerTrainer(Trainer t) {
	 * System.out.println("trainer impl"); sf.getCurrentSession().persist(t);
	 * 
	 * 
	 * return "Trainer registered successfully"+t.getT_ID(); }
	 * 
	 */

}
