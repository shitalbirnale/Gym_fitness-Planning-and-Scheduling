package com.app.dao;

import java.util.List;

import com.app.pojos.Admin;
import com.app.pojos.Member;
import com.app.pojos.Trainer;


public interface Interface_Admin {
	
	
	Admin authanticate(String email,String pass) throws Exception;
	
	public List<Trainer> getAllTrainer();

	public List<Member> getAllMember();

	String deleteMember(int m_Id);	


	String deleteTrainer(int t_ID);
	
	Member Search_Member(String name);
	

	Trainer Search_Trainer(String name);
	//String registerTrainer(Trainer t);
}
