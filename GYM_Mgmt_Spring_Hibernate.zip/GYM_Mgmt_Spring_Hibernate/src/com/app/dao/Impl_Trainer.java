package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Member;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

@Repository
@Transactional
public class Impl_Trainer implements Interface_Trainer {

	@Autowired
	private SessionFactory sf;

	// login authentication
	@Override
	public Trainer authanticate(String email, String pass) throws Exception {
		String jpql = "select t from Trainer t where t.email=:em and t.t_password=:pwd";

		return sf.getCurrentSession().createQuery(jpql, Trainer.class).setParameter("em", email)
				.setParameter("pwd", pass).getSingleResult();
	}

	// Register trainer
	@Override
	public String registerTrainer(Trainer t) {
		System.out.println("trainer impl");
		sf.getCurrentSession().persist(t);

		return "Trainer registered successfully" + t.getT_ID();
	}

	// get Particular Trainer
	@Override
	public Trainer getTrainerById(int tid) {
		// TODO Auto-generated method stub
		String jpql = "select t from Trainer t where t.t_ID=:tid";
		sf.getCurrentSession().get(Trainer.class, tid);
		return sf.getCurrentSession().createQuery(jpql, Trainer.class).setParameter("tid", tid).getSingleResult();
	}

	// Get Member list
	@Override
	public List<Member> getAllMember() {

		System.out.println("in  all member");

		String jpql = "select m from Member m";

		System.out.println("in member dao jpql");

		return sf.getCurrentSession().createQuery(jpql, Member.class).getResultList();

	}

	// get Member with His Trainer
	@Override
	public List<Member> getAllMemberbyTid(int tid) {

		System.out.println("in  all member");

		String jpql = "select m from Member m where m.trainer.t_ID=:tid";

		System.out.println("in member dao jpql");

		return sf.getCurrentSession().createQuery(jpql, Member.class).setParameter("tid", tid).getResultList();

	}

	// Delete Member
	@Override
	public String deleteMember(int m_Id) {
		Session hs = sf.getCurrentSession();
		Member m = hs.get(Member.class, m_Id);
		if (m != null) {
			hs.delete(m);
			return "Member un-subscribed with ID " + m.getM_ID();
		}
		return "member deletion failed : Invalid Member ID";
	}

	// get Physical Information of member
	@Override
	public Physical_Info getPhysicalinfo(int m_Id) {
		Session hs = sf.getCurrentSession();
		// Member m = hs.get(Member.class, m_Id);

		String jpql = "select pi from Physical_Info pi where pi.member.m_ID=:m_Id";

		return sf.getCurrentSession().createQuery(jpql, Physical_Info.class).setParameter("m_Id", m_Id)
				.getSingleResult();
	}

	// update physical info

	@Override
	public String PhysicalInfoUpdate(int bmi, float weight, float fat, int m) {
		Session hs = sf.getCurrentSession();
		// Member m = hs.get(Member.class, );

		System.out.println("MEMBER ID" + m);

		Member m1 = sf.getCurrentSession().get(Member.class, m);

		String jpql = "select p from Physical_Info p where p.member.m_ID=:mid";

		Physical_Info p = sf.getCurrentSession().createQuery(jpql, Physical_Info.class).setParameter("mid", m)
				.getSingleResult();

		Physical_Info p1 = sf.getCurrentSession().get(Physical_Info.class, p.getP_id());

		System.out.println(p1);

		if (p1 != null) {
			p1.setMember(m1);
			p1.setAge(bmi);
			p1.setFat(fat);
			p1.setWeight(weight);

			sf.getCurrentSession().update(p1);

		}

		System.out.println("updated data in update dao");

		return "data updated with " + p.getP_id();
	}

	// get workout program details
	@Override
	public WorkOutProgram getWorkOutProgram(int m_Id) {

		Session hs = sf.getCurrentSession();
		System.out.println("in get workout in dao impl");

		String jpql = "select wk from WorkOutProgram wk where wk.member.m_ID=:m_Id";

		return sf.getCurrentSession().createQuery(jpql, WorkOutProgram.class).setParameter("m_Id", m_Id)
				.getSingleResult();
	}

	// update the workout type
	@Override
	public String WorkOutProgramUpdate(String workouttype, int duration, String dietplan, int mid, int tid) {

		Session hs = sf.getCurrentSession();

		// Member m1=sf.getCurrentSession().get(Member.class, mid);

		String jpql = "select wk from WorkOutProgram wk where wk.member.m_ID=:m_Id and wk.trainer.t_ID=:t_Id";

		WorkOutProgram w = sf.getCurrentSession().createQuery(jpql, WorkOutProgram.class).setParameter("m_Id", mid)
				.setParameter("t_Id", tid).getSingleResult();
		System.out.println(w);
		if (w != null) {
			w.setDiet_plan(dietplan);
			w.setDuration(duration);
			w.setWorkouttype(workouttype);

			sf.getCurrentSession().update(w);
		}

		return "updated";
	}

	// insert physical information Of Member

	@Override
	public String InsertPhysicalInfo(Physical_Info p, int m) {

		System.out.println("insert physical info impl");

		Session hs = sf.getCurrentSession();

		Member member = hs.get(Member.class, m);

		member.setPhysical_info(p);

		p.setMember(member);

		hs.update(member);

		return "physical info registered successfully" + p.getP_id();
	}

	// Insert Member Workout Program (If New Member Is Join)
	@Override
	public String Insert_Workout_Program(WorkOutProgram wp, int n) {

		Session hs = sf.getCurrentSession();

		Member member = hs.get(Member.class, n);

		member.setWorkoutprogram(wp);

		wp.setMember(member);

		hs.update(member);

		return "Workout program Registered Successfully " + wp.getW_id();
	}

	// Search Member By Name
	@Override
	public Member Search_Member(String names) {

		String jpql = "select m from Member m where m.name=:names";

		System.out.println("in search Member in dao");

		Member m = sf.getCurrentSession().createQuery(jpql, Member.class).setParameter("names", names)
				.getSingleResult();

		return m;
	}

}
