package com.app.dao;

import java.util.List;

import com.app.pojos.Member;
import com.app.pojos.Physical_Info;
import com.app.pojos.Trainer;
import com.app.pojos.WorkOutProgram;

public interface Interface_Trainer {

	Trainer	authanticate(String email,String pass) throws Exception;
	
	String registerTrainer(Trainer t);
	
	Trainer getTrainerById(int tid);
	
	public List<Member> getAllMember();
	
	String deleteMember(int m_Id);	
	
	public Physical_Info getPhysicalinfo(int m_Id);
	
	String PhysicalInfoUpdate(int bmi,float weight,float fat,int m);
	
	public WorkOutProgram getWorkOutProgram(int m_Id);
	
	String WorkOutProgramUpdate(String workouttype,int duration,String dietplan,int mid,int tid);
	
	public List<Member> getAllMemberbyTid(int tid);
	
	
	String InsertPhysicalInfo(Physical_Info p,int m);
	
	String Insert_Workout_Program(WorkOutProgram wp,int n);
	
	
	Member Search_Member(String name);
	
}
